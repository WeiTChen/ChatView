//
//  AppDelegate.h
//  testfile
//
//  Created by William on 15/12/18.
//  Copyright © 2015年 William. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

