//
//  ChatView.h
//  testfile
//
//  Created by William on 15/12/18.
//  Copyright © 2015年 William. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ChatView;
@protocol ChatViewDelegate<NSObject>

-(void)chatViewBeginEditing;
-(void)chatViewEndEditing;
-(void)chatViewSizeH:(CGFloat)sizeH;
@end

typedef void(^BtnSelector)(NSString * text);
typedef void(^leftBtnSelector)(NSString *text);
/**
 *
 *  1.不要在外部设置frame
 *  2.可以通过block自定义UI
 */

@interface ChatView : UIView<UITextViewDelegate,UIGestureRecognizerDelegate>

@property (nonatomic,strong) UITextView *textView;
@property (nonatomic,strong) UILabel *leftLabel;
@property (nonatomic,strong) UIImageView *leftImageView;
@property (nonatomic,strong) UIButton *rightButton;
@property (nonatomic,strong) UIImageView *chatImageView;
@property (nonatomic,assign) NSInteger UIType;
@property (nonatomic,copy) BtnSelector BtnSelector;
@property (nonatomic,copy) leftBtnSelector leftBtnSelector;
@property (nonatomic,weak) UIView *delegateView;
@property (nonatomic,strong) NSString *zanNum;
@property (nonatomic,strong) UILabel *placeHolderLabel;
@property (nonatomic,copy)NSString * placeholder;///<默认文字

@property (nonatomic,weak)id<ChatViewDelegate> delegate;

-(id)initWithFrame:(CGRect)frame withType:(NSInteger)type;

//- (void)resetInputFrame:(CGRect)rect;
@end
