//
//  ViewController.m
//  testfile
//
//  Created by William on 15/12/18.
//  Copyright © 2015年 William. All rights reserved.
//

#import "ViewController.h"
#import "ChatView.h"
#define WEAKSELF __weak typeof(self) __weakSelf = self;
#define SCREN_W [UIScreen mainScreen].bounds.size.width
#define SCREN_H [UIScreen mainScreen].bounds.size.height

@interface ViewController ()<UITextViewDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *tab;
@property (nonatomic,strong) NSMutableArray *chatAry;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor orangeColor];
    [self initUI];
    _chatAry = [NSMutableArray array];
}

- (void)initUI
{
    _tab = [[UITableView alloc]initWithFrame:CGRectMake(0, 30, SCREN_W, SCREN_H-45)];
    UIView *v = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 1, 1)];
    _tab.tableFooterView = v;
    _tab.delegate = self;
    _tab.dataSource = self;
    _tab.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_tab];
    
    [self initChatView];
}

- (void)initChatView
{
    ChatView *chat = [[ChatView alloc]initWithFrame:CGRectMake(0,SCREN_H - 45 , self.view.frame.size.width, 45)withType:1];
    chat.leftImageView.image = [UIImage imageNamed:@"btn_nor_zan"];
    chat.leftLabel.text = @"10";
    __block UIImageView *img = chat.leftImageView;
    chat.leftBtnSelector = ^(NSString *text){
        if (img.alpha != 1)
        {
            img.image = [UIImage imageNamed:@"btn_nor_zan"];
            img.alpha = 1;
            return;
        }
        else
        {
            img.image = [UIImage imageNamed:@"btn_sel_zan"];
            img.alpha = 0.9;
        }
        
    };
    
    [self.view addSubview:chat];
    chat.BtnSelector = ^(NSString *text){
        [_chatAry addObject:text];
        [_tab reloadData];
        NSLog(@"%@",text);
    };
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _chatAry.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *iden = @"iden";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:iden];
    if (!cell)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:iden];
    }
    cell.textLabel.text = _chatAry[indexPath.row];
    [self.view addSubview:cell];
    
    return cell;
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}



@end
