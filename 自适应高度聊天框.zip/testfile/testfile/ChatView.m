//
//  ChatView.m
//  testfile
//
//  Created by William on 15/12/18.
//  Copyright © 2015年 William. All rights reserved.
//

#define SCREN_W [UIScreen mainScreen].bounds.size.width
#define SCREN_H [UIScreen mainScreen].bounds.size.height
#define RGBCOLOR(R,G,B) [UIColor colorWithRed:R/255.0 green:G/255.0 blue:B/255.0 alpha:1]

#import "ChatView.h"

@implementation ChatView
{
    CGRect _rect;
    int _height;
    int width;
    UILabel *label;
    NSInteger _newType;
    UIImage *_likeImage;
}

#pragma mark - 懒加载
- (UILabel *)placeHolderLabel
{
    if (!_placeHolderLabel)
    {
        
        _placeHolderLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, _textView.frame.size.width, _textView.frame.size.height)];
        _placeHolderLabel.text = @"请输入评论内容";
        _placeHolderLabel.textAlignment = NSTextAlignmentLeft;
        _placeHolderLabel.center = CGPointMake(_textView.frame.size.width/2+5, _textView.frame.size.height/2);
        _placeHolderLabel.textColor = RGBCOLOR(170, 170, 170);
    }
    return _placeHolderLabel;
}

#pragma mark - 初始化
-(id)initWithFrame:(CGRect)frame withType:(NSInteger)type{
    self=[super initWithFrame:frame];
    if (self) {
        [self initUIWithType:type];
        _newType = type;
        _rect = frame;
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    if (!_newType)
    {
       _newType = _UIType;
    }
    if (_UIType)
    {
        [self initUIWithType:_UIType];
    }
    
}

- (void)initUIWithType:(NSInteger)type
{
    
    switch (type)
    {
        case 1:
            self.backgroundColor =RGBCOLOR(236, 236, 236);
            _textView = [[UITextView alloc]initWithFrame:CGRectMake(10,  self.frame.size.height *0.2,self.frame.size.width*0.77, self.frame.size.height *0.6)];
            [self addSubview:_textView];
            _textView.font=[UIFont systemFontOfSize:17];
            _textView.layer.cornerRadius=8;
            _textView.delegate = self;
            
            
            
            width = _textView.frame.size.width + _textView.frame.origin.x;
            _rightButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, (self.frame.size.width- width) *0.6, _textView.frame.size.height)];
            

            [_rightButton addTarget:self action:@selector(buttonBlock) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:_rightButton];
            _rightButton.center = CGPointMake((self.frame.size.width + width)/2, _textView.center.y);
            label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, _rightButton.frame.size.width*0.75, _textView.frame.size.height*0.75)];
            label.center = _rightButton.center;
            label.text = @"发布";
            label.adjustsFontSizeToFitWidth = YES;
            [self addSubview:label];
            _UIType = 0;
             _height = _textView.contentSize.height/[self getHeight:_textView]-1;
            [_textView addSubview:self.placeHolderLabel];
            
            _textView.contentSize = _textView.frame.size;

            break;
        case 2:
            self.backgroundColor =RGBCOLOR(236, 236, 236);
            _leftImageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, self.frame.size.height*0.15, self.frame.size.width*0.05, self.frame.size.width*0.05)];
            [self addSubview:_leftImageView];
            [self addTap];
            _leftLabel = [[UILabel alloc]initWithFrame:CGRectMake(15, _leftImageView.frame.size.height + _leftImageView.frame.origin.y + 2, self.frame.size.width*0.1, self.frame.size.width*0.04)];
            [self addSubview:_leftLabel];
            _leftImageView.center = CGPointMake(_leftLabel.center.x,self.frame.size.height*0.15+ self.frame.size.width*0.025);
            _leftLabel.textAlignment=NSTextAlignmentCenter;
            _leftLabel.font=[UIFont systemFontOfSize:15];
            _leftLabel.text = _zanNum;
            
            _textView = [[UITextView alloc]initWithFrame:CGRectMake(15+_leftLabel.frame.size.width + 15,  self.frame.size.height *0.2,self.frame.size.width*0.7, self.frame.size.height *0.6)];
            _textView.font=[UIFont systemFontOfSize:17];
            [self addSubview:_textView];
            _textView.layer.cornerRadius=8;
            _textView.delegate = self;
            
            [_textView addSubview:self.placeHolderLabel];
            
            width = _textView.frame.size.width + _textView.frame.origin.x;
            _rightButton = [[UIButton alloc]initWithFrame:CGRectMake(width, 10, self.frame.size.width- width, _textView.frame.size.height)];
            [_rightButton addTarget:self action:@selector(buttonBlock) forControlEvents:UIControlEventTouchUpInside];
//            _rightButton.backgroundColor = [UIColor blueColor];
            label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, _rightButton.frame.size.width*0.75, _textView.frame.size.height*0.75)];
            label.center = _rightButton.center;
            label.text = @"发布";
            label.adjustsFontSizeToFitWidth = YES;
            [self addSubview:label];
            [_rightButton setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
            [self addSubview:_rightButton];
            _UIType = 0;
            _height = _textView.contentSize.height/[self getHeight:_textView]-1;
            
            _textView.contentSize = _textView.frame.size;
            break;
        default:
            break;
    }
    
}
- (void)typeOne:(UITextView *)textView
{
    int height = [self getHeight:textView];
    int colomNumber = textView.contentSize.height/height-1;
    if (colomNumber < 4)
    {
        [UIView animateWithDuration:0.3 animations:^{
            if (_height < colomNumber)
            {
                self.frame = CGRectMake(self.frame.origin.x,-height+self.frame.origin.y, self.frame.size.width,height+self.frame.size.height);
                textView.frame = CGRectMake(_textView.frame.origin.x, self.frame.size.height *0.2, _textView.frame.size.width, self.frame.size.height *0.6);
                width = _textView.frame.size.width + _textView.frame.origin.x;
                _rightButton.center = CGPointMake((self.frame.size.width + width)/2, _textView.center.y);
                _height = colomNumber;
                label.center = _rightButton.center;
            }
            else if (_height > colomNumber)
            {
                self.frame = CGRectMake(self.frame.origin.x,height+self.frame.origin.y, self.frame.size.width,-height+self.frame.size.height);
                textView.frame = CGRectMake(_textView.frame.origin.x,self.frame.size.height *0.2, _textView.frame.size.width, self.bounds.size.height*0.6);
                width = _textView.frame.size.width + _textView.frame.origin.x;
                _rightButton.center = CGPointMake((self.frame.size.width + width)/2, _textView.center.y);
                _height = colomNumber;
                label.center = _rightButton.center;
            }
            
        }];
    }
}

- (void)typeTwo:(UITextView *)textView
{
    int height = [self getHeight:textView];
    int colomNumber = textView.contentSize.height/height-1;
    int kongbai = self.frame.size.height - _textView.frame.size.height - _textView.frame.origin.y;
    if (colomNumber < 4)
    {
        [UIView animateWithDuration:0.3 animations:^{
            if (_height < colomNumber)
            {
                self.frame = CGRectMake(self.frame.origin.x,-height+self.frame.origin.y, self.frame.size.width,height+self.frame.size.height);
                width = _textView.frame.size.width + _textView.frame.origin.x;
                
                
                _leftLabel.frame = CGRectMake(15, self.frame.size.height - self.frame.size.width*0.04 - kongbai, self.frame.size.width*0.1, self.frame.size.width*0.04);
                _leftImageView.center = CGPointMake(_leftLabel.center.x,_leftLabel.frame.origin.y-_leftImageView.frame.size.height/2-2);
                _textView.frame = CGRectMake(_leftLabel.frame.origin.x+_leftLabel.frame.size.width + 15,  self.frame.size.height *0.2,self.frame.size.width*0.7, self.frame.size.height *0.6);
                _rightButton.center = CGPointMake((self.frame.size.width + width)/2,self.frame.size.height - (self.frame.size.height - _textView.frame.size.height - _textView.frame.origin.y) - _rightButton.frame.size.height/2);
                _height = colomNumber;
                label.center = _rightButton.center;
            }
            else if (_height > colomNumber)
            {
                self.frame = CGRectMake(self.frame.origin.x,height+self.frame.origin.y, self.frame.size.width,-height+self.frame.size.height);
                _leftLabel.frame = CGRectMake(15, self.frame.size.height - self.frame.size.width*0.04 - kongbai, self.frame.size.width*0.1, self.frame.size.width*0.04);
                _leftImageView.center = CGPointMake(_leftLabel.center.x,_leftLabel.frame.origin.y-_leftImageView.frame.size.height/2-2);
                _textView.frame = CGRectMake(_leftLabel.frame.origin.x+_leftLabel.frame.size.width + 15,  self.frame.size.height *0.2,self.frame.size.width*0.7, self.frame.size.height *0.6);
                width = _textView.frame.size.width + _textView.frame.origin.x;
                _rightButton.center = CGPointMake((self.frame.size.width + width)/2,self.frame.size.height - kongbai - _rightButton.frame.size.height/2);
                _height = colomNumber;
                label.center = _rightButton.center;
            }
            
        }];
    }
}


- (int)getHeight:(UITextView *)textView
{
    CGSize size =  [textView.text boundingRectWithSize:CGSizeMake(MAXFLOAT, 80) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:17]} context:nil].size;
    return size.height;
}
#pragma mark - 按钮点击事件
- (void)buttonBlock
{
    _likeImage = _leftImageView.image;
    NSString *zan = _leftLabel.text;
    NSString *chat = _textView.text;
    if ([chat isKindOfClass:[NSNull class]]||[chat isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请输入评论内容" delegate:nil cancelButtonTitle:@"确认" otherButtonTitles: nil];
        [alert show];
        return;
    }
    //移出之前所有控件,重新创建
    for (UIView *v in self.subviews)
    {
        [v removeFromSuperview];
    }
    self.frame = _rect;
    [self initUIWithType:_newType];
    _leftImageView.image = _likeImage;
    _leftLabel.text = zan;
    _likeImage = nil;
    if (_BtnSelector)
    {
        _BtnSelector(chat);
    }

}

#pragma mark - 左侧图片按钮回调
/**
 *  可以在selectorLeft函数中重写点击事件
 */
- (void)addTap
{
    UIButton *b = [[UIButton alloc]initWithFrame:_leftImageView.frame];
    [self addSubview:b];
    [b addTarget:self action:@selector(selectorLeft) forControlEvents:UIControlEventTouchUpInside];
}

- (void)selectorLeft
{
    if (_leftBtnSelector)
    {
        _leftBtnSelector(_leftLabel.text);
    }
}


#pragma mark - textViewDelegate
- (void)textViewDidChange:(UITextView *)textView
{
    if (_newType == 1)
    {
        [self typeOne:textView];
        if (self.delegate&&[self.delegate respondsToSelector:@selector(chatViewSizeH:)]) {
            CGFloat h=self.frame.size.height;
            [self.delegate chatViewSizeH:h];
        }
    }
    if (_newType == 2)
    {
        [self typeTwo:textView];
    }
    if (textView.text.length == 0)
    {
        _textView.contentSize = textView.frame.size;
        [textView addSubview:self.placeHolderLabel];
    }
    else
    {
        [self.placeHolderLabel removeFromSuperview];
    }
}

-(void)chatViewEndEditing{
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    _delegateView.frame = CGRectMake(0, 0, _delegateView.frame.size.width, _delegateView.frame.size.height);
    [UIView commitAnimations];
    
}
- (void)textViewDidBeginEditing:(UITextView *)textView{
    if (self.delegate&&[self.delegate respondsToSelector:@selector(chatViewBeginEditing)]) {
        [self.delegate chatViewBeginEditing];
    }
    [_placeHolderLabel removeFromSuperview];
    _placeHolderLabel = nil;
    int offset = 0;
    offset = 216 - (SCREN_H - self.frame.size.height - self.frame.origin.y - 34);
    //键盘高度216,导航和高度为96
    if (offset > 0)
    {
        NSTimeInterval animationDuration = 0.30f;
        [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
        [UIView setAnimationDuration:animationDuration];
        
        //将视图的Y坐标向上移动offset个单位，以使下面腾出地方用于软键盘的显示
        //if(offset > 0)
        _delegateView.frame = CGRectMake(0.0f, -offset, _delegateView.frame.size.width, _delegateView.frame.size.height);
        [UIView commitAnimations];
    }
}
- (void)textViewDidEndEditing:(UITextView *)textView{
    if (self.delegate&&[self.delegate respondsToSelector:@selector(chatViewEndEditing)]) {
        [self.delegate chatViewEndEditing];
    }
    [UIView animateWithDuration:0.3 animations:^{
        _delegateView.frame = CGRectMake(0, 0, SCREN_W, SCREN_H);
    }];
    if (textView.text.length == 0)
    {
        textView.contentSize = textView.frame.size;
        [textView addSubview:self.placeHolderLabel];
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text; {
    
    if ([@"\n" isEqualToString:text] == YES) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}


//-(void)chatViewShouldReturn{
//    NSTimeInterval animationDuration = 0.30f;
//    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
//    [UIView setAnimationDuration:animationDuration];
//    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
//
//    [UIView commitAnimations];
//}


@end
